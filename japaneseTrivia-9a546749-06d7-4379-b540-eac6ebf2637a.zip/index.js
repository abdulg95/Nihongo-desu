'use strict';
var Alexa = require("alexa-sdk");
const appId = ''; //'amzn1.echo-sdk-ams.app.your-skill-id';
var greetingDict = [{"Good Morning":"Ohayoo Gozaimasu"},
                    {"Good afternoon":"konni chi wa"},
                    {"Good evening":"kon ban wa"},
                    {"Goodnight":"oyasumi nasai"},
                    {"Goodbye":"sayonara"},
                    {"nice to meet you":"hajimeshite"}]
                    
var numbersDict = [{"one":"ichi"},
                   {"two":"ni"},
                   {"threee":"san"},
                   {"four":"yon"},
                   {"five":"go"},
                   {"six":"roku"},
                   {"seven":"nana"},
                   {"eight":"hachi"},
                   {"nine":"kyu"},
                   {"ten":"jyu"},
                   {"one hundred":"hyaku"},
                   {"one thousand":"sen"}]
                   
var convoDict = [{"yes":"hai"},
                 {"no":"lie"},
                 {"do you understand":"wakarimasuka"},
                 {"i don't understand":"wakarimasen"},
                 {"i understand":"wakarimasu"},
                 {"thank you":"arigato"}]
    
var welcomeMessage;              
//var myName = this.event.request.intent.slots.name.value;

   // if (myName) {
        welcomeMessage = "Yookoso "+"Say yes to learn and no to take quiz"
    //}

//adapted from code on https://developer.amazon.com/docs/custom-skills/use-the-alexa-skills-kit-samples.html#getting-the-source-code-for-the-samples-and-java-library

exports.handler = function(event, context, callback) {
    const alexa = Alexa.handler(event, context);
    alexa.appId = appId;
    alexa.registerHandlers(newSessionHandlers,  quizModeHandlers, startGameHandlers);
    alexa.execute();
};

const states = {
    STARTMODE: '_STARTMODE',
    QUIZMODE: '_QUIZMODE', // User is trying to take quiz.
    LEARNMODE: '_LEARNMODE'  // user is trying to learn words.
};

const newSessionHandlers = {
    'NewSession': function() {
        if(Object.keys(this.attributes).length === 0) {
            this.attributes['endedSessionCount'] = 0;
            this.attributes['gamesPlayed'] = 0;
        }
        this.handler.state = states.QUIZMODE;
        this.response.speak(welcomeMessage).listen('Say yes to start the game or no to quit.');
        this.emit(':responseReady');
    },
    "AMAZON.StopIntent": function() {
      this.response.speak("Sayoonara!");
      this.emit(':responseReady');
    },
    "AMAZON.CancelIntent": function() {
        this.response.speak("Sayoonara!");
        this.emit(':responseReady');
    },
    'SessionEndedRequest': function () {
        console.log('session ended!');
        this.response.speak("Sayoonara!");
        this.emit(':responseReady');
    }
};

    const startGameHandlers = Alexa.CreateStateHandler(states.LEARNMODE, {
    'NewSession': function () {
        this.emit('NewSession'); // Uses the handler in newSessionHandlers
    },
    'AMAZON.HelpIntent': function() {
        this.response.speak(welcomeMessage).listen(welcomeMessage);
        this.emit(':responseReady');
    },
    'AMAZON.YesIntent': function() {
       
    },
    'AMAZON.NoIntent': function() {
        console.log("NOINTENT");
        this.response.speak('Bye Bye!');
        this.emit(':responseReady');
    },
    "AMAZON.StopIntent": function() {
      console.log("STOPINTENT");
      this.response.speak("Sayoonara!");
      this.emit(':responseReady');
    },
    "AMAZON.CancelIntent": function() {
      console.log("CANCELINTENT");
      this.response.speak("Sayoonara!");
      this.emit(':responseReady');
    },
    'SessionEndedRequest': function () {
        console.log("SESSIONENDEDREQUEST");
        //this.attributes['endedSessionCount'] += 1;
        this.response.speak("Sayoonara!");
        this.emit(':responseReady');
    },
    'Unhandled': function() {
        console.log("UNHANDLED");
        this.response.speak(welcomeMessage).listen(welcomeMessage);
        this.emit(':responseReady');
    }
});

const quizModeHandlers = Alexa.CreateStateHandler(states.QUIZMODE, {
   
    'AMAZON.HelpIntent': function() {
        shuffle(greetingDict)
        shuffle(numbersDict)
        shuffle(convoDict)
        for (let i = 0; i < greetingDict.length/2; i++) {
            this.response.speak("What is "+greetingDict[i].value+" in english").listen('Try again.');
            this.emit(':responseReady');
           // var greetingSlot = this.event.request.intent.slots.greeting.value;
        //    if(greetingSlot == greetingDict[i].keys[0]){
       //         this.response.speak("context");
         //       this.emit(':responseReady');
          //  }
                
         }
         for (let i = 0; i < numbersDict.length/2; i++) {
             var x = 0;
            this.response.speak("What is " +" in english").listen('Try again.');
            this.emit(':responseReady');
           //  var numbersSlot = this.event.request.intent.slots.numbers.value;
           //  if(numbersSlot == numbersDict[i].keys[0]){
           //     this.response.speak("correct");
            //    this.emit(':responseReady');
            //}
         }
         for (let i = 0; i < convoDict.length/2; i++) {
            this.response.speak("What is "+convoDict[i].value+" in english").listen('Try again.');
            this.emit(':responseReady');
           //  var convoSlot = this.event.request.intent.slots.convo.value;
       //      if(convoSlot == convoDict[i].keys[0]){
         //       this.response.speak("correct");
           //     this.emit(':responseReady');
            //}
         }

        
    },
    "AMAZON.StopIntent": function() {
        console.log("STOPINTENT");
      this.response.speak("Goodbye!");
      this.emit(':responseReady');
    },
    "AMAZON.CancelIntent": function() {
        console.log("CANCELINTENT");
    },
    'SessionEndedRequest': function () {
        console.log("SESSIONENDEDREQUEST");
        this.attributes['endedSessionCount'] += 1;
        this.response.speak("Sayoonara!");
        this.emit(':responseReady');
    },
    'Unhandled': function() {
        console.log("UNHANDLED");
        this.response.speak('Could you repeat that?').listen('I can\'t hear you?');
        this.emit(':responseReady');
    }
});
//stack overflow shuffle code https://stackoverflow.com/questions/6274339/how-can-i-shuffle-an-array
function shuffle(a) {
    var j, x, i;
    for (i = a.length - 1; i > 0; i--) {
        j = Math.floor(Math.random() * (i + 1));
        x = a[i];
        a[i] = a[j];
        a[j] = x;
    }
}
